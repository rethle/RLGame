namespace RLTools;

public enum Directions
{
    Horizontal,
    Vertical,
}